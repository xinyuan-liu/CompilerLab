package minijava.typecheck;

public class TypeErrorException extends Exception {
	TypeErrorException(String msg){
		super(msg);
	}
}
